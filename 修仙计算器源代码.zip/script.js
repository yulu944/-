<script>
        // 单位到指数的映射（每级相差10000倍，即10^4）
        const unitExponents = {
            '穰': 28,
            '沟': 32,  // 穰 + 4
            '涧': 36,  // 沟 + 4
            '正': 40,  // 涧 + 4
            '载': 44,  // 正 + 4
            '极': 48,  // 载 + 4
            '恒河沙': 52,  // 极 + 4
            '阿僧祇': 56,  // 恒河沙 + 4
            '那由他': 60,  // 阿僧祇 + 4
            '不可思议': 64,  // 那由他 + 4
            '无量': 68,  // 不可思议 + 4
            '大数': 72,  // 无量 + 4
            '无敌': 76   // 大数 + 4
        };
        
        // 轮回次数对应的基础生命上限
        const reincarnationHpCaps = {
            '0': { value: 250, unit: '涧' },
            '1': { value: 7500, unit: '涧' },
            '2': { value: 23.3, unit: '正' },
            '3': { value: 744, unit: '正' },
            '4': { value: 2.46, unit: '载' },
            '5': { value: 83.50, unit: '载' },
            '6': { value: 2920, unit: '载' },
            '7': { value: 10.5, unit: '极' },
            '8': { value: 389, unit: '极' },
            '9': { value: 1.50, unit: '恒河沙' }
        };
        
        // 单位列表（按从小到大排序）
        const unitList = [
            '穰', '沟', '涧', '正', '载', '极', 
            '恒河沙', '阿僧祇', '那由他', '不可思议', 
            '无量', '大数', '无敌'
        ];
        
        // 获取DOM元素
        const form = document.getElementById('calculatorForm');
        const calculateButton = document.getElementById('calculateButton');
        const resultSection = document.getElementById('resultSection');
        const resultContent = document.getElementById('resultContent');
        const resetButton = document.getElementById('resetButton');
        const talentLevelInput = document.getElementById('talentLevel');
        const growthRateDisplay = document.getElementById('growthRateDisplay');
        
        // 功能选择相关元素
        const functionSelect = document.getElementById('functionSelect');
        const targetPowerGroup = document.getElementById('targetPowerGroup');
        const targetTimeGroup = document.getElementById('targetTimeGroup');
        const powerCapGroup = document.getElementById('powerCapGroup');
        const talentLevelGroup = document.getElementById('talentLevelGroup');
        
        // 战力上限计算器相关元素
        const reincarnationCount = document.getElementById('reincarnationCount');
        const hpCapValue = document.getElementById('hpCapValue');
        const hpCapUnit = document.getElementById('hpCapUnit');
        
        // 计算模式相关元素
        const calculationMode = document.getElementById('calculationMode');
        const bathTimeInputGroup = document.getElementById('bathTimeInputGroup');
        const magicPillInputGroup = document.getElementById('magicPillInputGroup');
        
        // 轮回次数变化事件处理
        reincarnationCount.addEventListener('change', function() {
            const selectedValue = this.value;
            
            // 检查是否是0-9的轮回次数
            if (reincarnationHpCaps.hasOwnProperty(selectedValue)) {
                // 自动填充基础生命值上限
                const capData = reincarnationHpCaps[selectedValue];
                hpCapValue.value = capData.value;
                hpCapUnit.value = capData.unit;
                
                // 锁定输入框
                hpCapValue.disabled = true;
                hpCapUnit.disabled = true;
                hpCapValue.classList.add('bg-gray-100', 'text-gray-500', 'cursor-not-allowed');
                hpCapUnit.classList.add('bg-gray-100', 'text-gray-500', 'cursor-not-allowed');
            } else {
                // 10及以上，解锁输入框
                hpCapValue.disabled = false;
                hpCapUnit.disabled = false;
                hpCapValue.classList.remove('bg-gray-100', 'text-gray-500', 'cursor-not-allowed');
                hpCapUnit.classList.remove('bg-gray-100', 'text-gray-500', 'cursor-not-allowed');
                
                // 清空值，让用户自己输入
                hpCapValue.value = '';
            }
        });
        
        // 功能选择变化事件
        functionSelect.addEventListener('change', function() {
            // 重置所有组的显示状态
            targetPowerGroup.classList.add('hidden');
            targetTimeGroup.classList.add('hidden');
            powerCapGroup.classList.add('hidden');
            
            // 挂机天赋等级现在所有功能都需要，所以始终显示
            talentLevelGroup.classList.remove('hidden');
            
            // 根据选择显示对应组
            if (this.value === 'targetPower') {
                // 1. 指定战力计算
                targetPowerGroup.classList.remove('hidden');
            } else if (this.value === 'targetTime') {
                // 2. 指定时间计算
                targetTimeGroup.classList.remove('hidden');
                bathTimeInputGroup.classList.remove('hidden');
                magicPillInputGroup.classList.add('hidden');
            } else if (this.value === 'powerCap') {
                // 3. 战力上限计算器
                powerCapGroup.classList.remove('hidden');
                // 触发一次轮回次数的change事件，确保初始状态正确
                reincarnationCount.dispatchEvent(new Event('change'));
            }
        });
        
        // 计算模式变化事件
        calculationMode.addEventListener('change', function() {
            if (this.value === 'bathTime') {
                bathTimeInputGroup.classList.remove('hidden');
                magicPillInputGroup.classList.add('hidden');
            } else if (this.value === 'magicPill') {
                bathTimeInputGroup.classList.add('hidden');
                magicPillInputGroup.classList.remove('hidden');
            }
        });
        
        // 更新增长率显示
        talentLevelInput.addEventListener('input', function() {
            const level = parseInt(this.value) || 0;
            const clampedLevel = Math.max(0, Math.min(10, level));
            this.value = clampedLevel;
            
            const growthRate = 0.010 + clampedLevel * 0.001;
            growthRateDisplay.textContent = `当前每5秒增长: ${growthRate.toFixed(3)}%`;
        });
        
        // 计算按钮点击处理
        calculateButton.addEventListener('click', function() {
            try {
                const selectedFunction = functionSelect.value;
                
                // 获取现有战力值（所有功能都需要）
                const currentPower = parseFloat(document.getElementById('currentPower').value);
                const currentUnit = document.getElementById('currentUnit').value;
                
                // 验证现有战力输入
                if (isNaN(currentPower) || currentPower <= 0) {
                    alert('请输入有效的现有战力数值（必须大于0）');
                    return;
                }
                
                // 计算当前战力的实际值（转换为10的幂次方）
                const currentPowerValue = currentPower * Math.pow(10, unitExponents[currentUnit]);
                
                // 获取挂机天赋等级（所有功能都需要）
                const talentLevel = parseInt(document.getElementById('talentLevel').value) || 0;
                if (talentLevel < 0 || talentLevel > 10) {
                    alert('挂机天赋等级必须在0-10之间');
                    return;
                }
                
                // 根据选择的功能执行不同的计算和验证
                let resultHtml = '';
                
                if (selectedFunction === 'targetPower') {
                    // 1. 指定战力计算 - 只验证当前功能所需字段
                    const targetPower = parseFloat(document.getElementById('targetPower').value);
                    const targetUnit = document.getElementById('targetUnit').value;
                    
                    // 验证当前功能所需字段
                    if (isNaN(targetPower) || targetPower <= 0) {
                        alert('请输入有效的目标战力数值（必须大于0）');
                        return;
                    }
                    
                    // 计算目标战力的实际值
                    const targetPowerValue = targetPower * Math.pow(10, unitExponents[targetUnit]);
                    
                    if (currentPowerValue >= targetPowerValue) {
                        alert('目标战力必须大于现有战力');
                        return;
                    }
                    
                    // 计算增长率（每5秒）
                    const growthRate = 0.010 + talentLevel * 0.001; // 百分比
                    const growthFactor = 1 + growthRate / 100; // 每5秒的增长因子
                    
                    // 计算需要多少个5秒周期才能达到目标
                    const ratio = targetPowerValue / currentPowerValue;
                    const cycles = Math.ceil(Math.log(ratio) / Math.log(growthFactor));
                    
                    // 总秒数
                    const totalSeconds = cycles * 5;
                    
                    // 计算等效无极魔丹数量（每颗增加0.01%）
                    const pillGrowthFactor = 1.0001; // 每颗魔丹的增长因子（0.01%）
                    const pillCount = Math.ceil(Math.log(ratio) / Math.log(pillGrowthFactor));
                    
                    // 格式化时间
                    const timeData = formatTime(totalSeconds);
                    
                    // 计算目标日期时间
                    const targetDate = new Date();
                    targetDate.setSeconds(targetDate.getSeconds() + totalSeconds);
                    
                    // 构建结果HTML
                    resultHtml = `
                        <div class="result-item p-4 bg-blue-50 rounded-lg border border-blue-100">
                            <h3 class="text-gray-700 font-medium mb-1">所需时间</h3>
                            <p class="text-lg font-semibold text-primary">${timeData.primaryTime}（${timeData.secondaryTime}）</p>
                        </div>
                        
                        <div class="result-item p-4 bg-purple-50 rounded-lg border border-purple-100">
                            <h3 class="text-gray-700 font-medium mb-1">预计达成时间</h3>
                            <p class="text-lg font-semibold text-accent">${formatDate(targetDate)}</p>
                        </div>
                        
                        <div class="result-item p-4 bg-amber-50 rounded-lg border border-amber-100">
                            <h3 class="text-gray-700 font-medium mb-1">需要等效无极魔丹数量</h3>
                            <p class="text-lg font-semibold text-amber-600">${pillCount.toLocaleString()}颗（${formatLargeNumber(pillCount)}）</p>
                        </div>
                    `;
                    
                } else if (selectedFunction === 'targetTime') {
                    // 2. 指定时间计算 - 只验证当前功能所需字段
                    let finalPowerValue;
                    
                    if (calculationMode.value === 'bathTime') {
                        // 2.1 泡澡时间模式
                        const days = parseInt(document.getElementById('bathDays').value) || 0;
                        const hours = parseInt(document.getElementById('bathHours').value) || 0;
                        
                        if (days <= 0 && hours <= 0) {
                            alert('请输入有效的泡澡时间（天数和小时数不能同时为0）');
                            return;
                        }
                        
                        // 计算总秒数
                        const totalSeconds = days * 86400 + hours * 3600;
                        // 计算5秒周期数
                        const cycles = Math.floor(totalSeconds / 5);
                        
                        // 计算增长率
                        const growthRate = 0.010 + talentLevel * 0.001; // 百分比
                        const growthFactor = 1 + growthRate / 100; // 每5秒的增长因子
                        
                        // 计算最终战力
                        finalPowerValue = currentPowerValue * Math.pow(growthFactor, cycles);
                        
                        // 构建结果HTML
                        resultHtml = `
                            <div class="result-item p-4 bg-green-50 rounded-lg border border-green-100">
                                <h3 class="text-gray-700 font-medium mb-1">泡澡时间</h3>
                                <p class="text-lg font-semibold text-green-600">${days}天${hours}小时（约${Math.round(totalSeconds / 3600)}小时）</p>
                            </div>
                            
                            <div class="result-item p-4 bg-gold-50 rounded-lg border border-gold-100">
                                <h3 class="text-gray-700 font-medium mb-1">最终战力</h3>
                                <p class="text-lg font-semibold text-gold-600">${formatPower(finalPowerValue)}</p>
                            </div>
                        `;
                        
                    } else if (calculationMode.value === 'magicPill') {
                        // 2.2 无极魔丹模式
                        const pillCount = parseInt(document.getElementById('pillCountInput').value) || 0;
                        
                        if (pillCount <= 0) {
                            alert('请输入有效的魔丹数量（必须大于0）');
                            return;
                        }
                        
                        // 每颗魔丹增加0.01%
                        const growthFactor = 1.0001; // 每颗魔丹的增长因子
                        
                        // 计算最终战力
                        finalPowerValue = currentPowerValue * Math.pow(growthFactor, pillCount);
                        
                        // 构建结果HTML
                        resultHtml = `
                            <div class="result-item p-4 bg-amber-50 rounded-lg border border-amber-100">
                                <h3 class="text-gray-700 font-medium mb-1">使用无极魔丹数量</h3>
                                <p class="text-lg font-semibold text-amber-600">${pillCount.toLocaleString()}颗（${formatLargeNumber(pillCount)}）</p>
                            </div>
                            
                            <div class="result-item p-4 bg-gold-50 rounded-lg border border-gold-100">
                                <h3 class="text-gray-700 font-medium mb-1">最终战力</h3>
                                <p class="text-lg font-semibold text-gold-600">${formatPower(finalPowerValue)}</p>
                            </div>
                        `;
                    }
                } else if (selectedFunction === 'powerCap') {
                    // 3. 战力上限计算器 - 只验证当前功能所需字段
                    // 获取基础生命值
                    const baseHp = parseFloat(document.getElementById('baseHp').value);
                    const baseHpUnit = document.getElementById('baseHpUnit').value;
                    
                    // 获取基础生命值上限
                    const hpCapValueNum = parseFloat(hpCapValue.value);
                    const hpCapUnitSelected = hpCapUnit.value;
                    
                    // 验证当前功能所需字段
                    if (isNaN(baseHp) || baseHp <= 0) {
                        alert('请输入有效的基础生命值（必须大于0）');
                        return;
                    }
                    
                    if (isNaN(hpCapValueNum) || hpCapValueNum <= 0) {
                        alert('请输入有效的基础生命值上限（必须大于0）');
                        return;
                    }
                    
                    // 转换为实际值
                    const baseHpValue = baseHp * Math.pow(10, unitExponents[baseHpUnit]);
                    const hpCapValueFinal = hpCapValueNum * Math.pow(10, unitExponents[hpCapUnitSelected]);
                    
                    // 应用公式：战力上限 = 现有战力 × 你的基础生命值上限 / 基础生命值
                    const powerCapValue = currentPowerValue * (hpCapValueFinal / baseHpValue);
                    
                    // 如果当前战力已经超过或等于上限
                    if (currentPowerValue >= powerCapValue) {
                        resultHtml = `
                            <div class="result-item p-6 bg-indigo-50 rounded-lg border border-indigo-100">
                                <p class="text-gray-700 mb-3">你目前属性的战力上限为：</p>
                                <p class="text-2xl font-bold text-indigo-600">${formatPower(powerCapValue)}</p>
                                <p class="mt-4 text-amber-600 font-medium">注意：你的当前战力已达到或超过战力上限</p>
                            </div>
                        `;
                    } else {
                        // 计算达到上限所需时间
                        const growthRate = 0.010 + talentLevel * 0.001; // 百分比
                        const growthFactor = 1 + growthRate / 100; // 每5秒的增长因子
                        const ratio = powerCapValue / currentPowerValue;
                        const cycles = Math.ceil(Math.log(ratio) / Math.log(growthFactor));
                        const totalSeconds = cycles * 5;
                        
                        // 格式化时间
                        const timeComponents = formatTimeComponents(totalSeconds);
                        
                        // 计算目标日期时间
                        const targetDate = new Date();
                        targetDate.setSeconds(targetDate.getSeconds() + totalSeconds);
                        
                        // 格式化结果
                        const formattedPowerCap = formatPower(powerCapValue);
                        
                        // 构建结果HTML
                        resultHtml = `
                            <div class="result-item p-6 bg-indigo-50 rounded-lg border border-indigo-100">
                                <p class="text-gray-700 mb-3">你目前属性的战力上限为：</p>
                                <p class="text-2xl font-bold text-indigo-600">${formattedPowerCap}</p>
                                
                                <div class="mt-6 pt-4 border-t border-indigo-100">
                                    <p class="text-gray-700 mb-2">到达战力上限还需泡澡时间：</p>
                                    <p class="text-lg font-semibold text-primary">${timeComponents.days}天${timeComponents.hours}小时${timeComponents.minutes}分钟</p>
                                    
                                    <p class="text-gray-700 mt-4 mb-2">预计到达战力上限的时间：</p>
                                    <p class="text-lg font-semibold text-accent">${formatDate(targetDate)}</p>
                                </div>
                            </div>
                        `;
                    }
                }
                
                // 显示结果
                resultContent.innerHTML = resultHtml;
                resultSection.classList.remove('hidden');
                resultSection.classList.add('animate-fadeIn');
                
                // 平滑滚动到结果区域
                resultSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
                
            } catch (error) {
                console.error('计算过程出错:', error);
                alert('计算过程中出现错误，请检查输入值是否合理');
            }
        });
        
        // 格式化时间（秒 -> 天、时、分）- 用于显示详细时间组件
        function formatTimeComponents(totalSeconds) {
            const totalMinutes = Math.round(totalSeconds / 60);
            const hours = Math.floor(totalMinutes / 60);
            const minutes = totalMinutes % 60;
            const days = Math.floor(hours / 24);
            const remainingHours = hours % 24;
            
            return {
                days: days,
                hours: remainingHours,
                minutes: minutes
            };
        }
        
        // 格式化时间（秒 -> 天、时、分）- 用于简洁显示
        function formatTime(totalSeconds) {
            const components = formatTimeComponents(totalSeconds);
            return {
                primaryTime: `${components.days * 24 + components.hours}小时${components.minutes}分钟`,
                secondaryTime: `${components.days}天${components.days > 0 ? '零' : ''}${components.hours}小时${components.minutes}分钟`
            };
        }
        
        // 格式化日期时间
        function formatDate(date) {
            const options = { 
                year: 'numeric', 
                month: '2-digit', 
                day: '2-digit', 
                hour: '2-digit', 
                minute: '2-digit',
                hour12: false
            };
            return date.toLocaleString('zh-CN', options);
        }
        
        // 格式化大数字显示
        function formatLargeNumber(num) {
            if (num < 1000) return num.toFixed(0);
            if (num < 1000000) return (num / 1000).toFixed(1) + 'K';
            if (num < 1000000000) return (num / 1000000).toFixed(1) + 'M';
            if (num < 1000000000000) return (num / 1000000000).toFixed(1) + 'B';
            return (num / 1000000000000).toFixed(1) + 'T';
        }
        
        // 格式化战力显示 - 选择最合适的单位
        function formatPower(powerValue) {
            // 特殊情况处理：值为0
            if (powerValue <= 0) {
                return "0 穰";
            }
            
            // 从最大的单位开始检查，找到最合适的单位
            for (let i = unitList.length - 1; i >= 0; i--) {
                const unit = unitList[i];
                const exponent = unitExponents[unit];
                const unitValue = Math.pow(10, exponent);
                
                // 如果数值大于等于当前单位的值，使用这个单位
                if (powerValue >= unitValue) {
                    const valueInUnit = powerValue / unitValue;
                    
                    // 检查是否需要转换到更大的单位（如果值 >= 10000）
                    if (i < unitList.length - 1 && valueInUnit >= 10000) {
                        const nextUnit = unitList[i + 1];
                        const nextExponent = unitExponents[nextUnit];
                        const valueInNextUnit = powerValue / Math.pow(10, nextExponent);
                        return `${valueInNextUnit.toFixed(2)} ${nextUnit}`;
                    }
                    
                    return `${valueInUnit.toFixed(2)} ${unit}`;
                }
            }
            
            // 默认使用最小单位
            return `${(powerValue / Math.pow(10, unitExponents['穰'])).toFixed(2)} 穰`;
        }
        
        // 重置按钮事件
        resetButton.addEventListener('click', function() {
            form.reset();
            resultSection.classList.add('hidden');
            talentLevelInput.dispatchEvent(new Event('input')); // 更新增长率显示
            // 重置显示状态
            targetPowerGroup.classList.remove('hidden');
            targetTimeGroup.classList.add('hidden');
            powerCapGroup.classList.add('hidden');
            bathTimeInputGroup.classList.remove('hidden');
            magicPillInputGroup.classList.add('hidden');
            // 重置基础生命值上限的状态
            hpCapValue.disabled = false;
            hpCapUnit.disabled = false;
            hpCapValue.classList.remove('bg-gray-100', 'text-gray-500', 'cursor-not-allowed');
            hpCapUnit.classList.remove('bg-gray-100', 'text-gray-500', 'cursor-not-allowed');
            form.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
        
        // 添加动画效果
        document.head.insertAdjacentHTML('beforeend', `
            <style>
                @keyframes fadeIn {
                    from { opacity: 0; transform: translateY(10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .animate-fadeIn {
                    animation: fadeIn 0.5s ease-out forwards;
                }
            </style>
        `);
    </script>